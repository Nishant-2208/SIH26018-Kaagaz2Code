"""
preprocessor.py — OpenCV preprocessing for scanned land-record images.

Pipeline: decode -> downscale -> grayscale -> denoise -> deskew -> CLAHE -> binarize.

Design note: we return BOTH the CLAHE grayscale and the binarized image. Hard
binarization helps on clean typed records but destroys thin Devanagari strokes on
faded/handwritten ones, where PaddleOCR does measurably better on the CLAHE image.
Which one is fed to OCR is an env switch (OCR_INPUT), not a code change.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Literal

import cv2
import numpy as np

logger = logging.getLogger(__name__)

# --- tunables -----------------------------------------------------------------
MAX_EDGE_PX: int = int(os.getenv("PREPROCESS_MAX_EDGE_PX", "2000"))
MAX_SKEW_DEG: float = float(os.getenv("PREPROCESS_MAX_SKEW_DEG", "15.0"))
BLUR_THRESHOLD: float = float(os.getenv("PREPROCESS_BLUR_THRESHOLD", "60.0"))
OCR_INPUT: Literal["clahe", "binary"] = os.getenv("OCR_INPUT", "clahe")  # type: ignore[assignment]


class ImageDecodeError(ValueError):
    """Raised when the uploaded bytes are not a decodable image."""


@dataclass
class PreprocessResult:
    """Everything downstream stages (and the debug endpoint) need."""

    ocr_input: np.ndarray  # 3-channel BGR — PaddleOCR expects HxWx3
    clahe_gray: np.ndarray  # single channel
    binary: np.ndarray  # single channel, 0/255
    width: int
    height: int
    skew_angle_deg: float
    blur_score: float  # variance of Laplacian; low == blurry
    is_likely_illegible: bool
    downscaled: bool


def decode_image(raw: bytes) -> np.ndarray:
    """Decode raw upload bytes into a BGR ndarray.

    Raises:
        ImageDecodeError: bytes are empty, truncated, or not an image format
            OpenCV can read (guards against a renamed .pdf or a zero-byte upload).
    """
    if not raw:
        raise ImageDecodeError("Empty file body.")
    buf = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    if img is None:
        raise ImageDecodeError("Bytes could not be decoded as an image (corrupt or unsupported format).")
    if img.shape[0] < 32 or img.shape[1] < 32:
        raise ImageDecodeError(f"Image too small to contain text: {img.shape[1]}x{img.shape[0]}px.")
    return img


def _downscale(img: np.ndarray, max_edge: int = MAX_EDGE_PX) -> tuple[np.ndarray, bool]:
    """Cap the long edge. Phone photos arrive at 4000px+ and cost ~4x OCR time
    for no accuracy gain once text height is above ~25px."""
    h, w = img.shape[:2]
    longest = max(h, w)
    if longest <= max_edge:
        return img, False
    scale = max_edge / float(longest)
    resized = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    logger.debug("Downscaled %dx%d -> %dx%d", w, h, resized.shape[1], resized.shape[0])
    return resized, True


def _estimate_skew(gray: np.ndarray) -> float:
    """Estimate page skew in degrees via the minimum-area rect of ink pixels.

    Returns 0.0 when the estimate is unreliable (too few ink pixels) or beyond
    MAX_SKEW_DEG — a 40-degree "correction" on a misread is far worse than none.
    """
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    coords = cv2.findNonZero(thresh)
    if coords is None or len(coords) < 100:
        logger.debug("Skew estimation skipped: insufficient ink pixels.")
        return 0.0

    angle = cv2.minAreaRect(coords)[-1]
    # OpenCV changed this API's range between versions: 4.5+ returns (0, 90],
    # older builds return [-90, 0). Normalising into (-45, 45] is correct for
    # both and avoids a spurious 90-degree "skew" on near-axis-aligned pages.
    while angle < -45.0:
        angle += 90.0
    while angle > 45.0:
        angle -= 90.0

    if abs(angle) > MAX_SKEW_DEG:
        logger.warning("Skew estimate %.2f deg exceeds clamp %.1f; not rotating.", angle, MAX_SKEW_DEG)
        return 0.0
    return float(angle)


def _rotate(img: np.ndarray, angle_deg: float) -> np.ndarray:
    """Rotate about the centre, expanding the canvas so no corner is clipped."""
    if abs(angle_deg) < 0.1:
        return img
    h, w = img.shape[:2]
    centre = (w / 2.0, h / 2.0)
    mat = cv2.getRotationMatrix2D(centre, angle_deg, 1.0)

    cos, sin = abs(mat[0, 0]), abs(mat[0, 1])
    new_w = int(h * sin + w * cos)
    new_h = int(h * cos + w * sin)
    mat[0, 2] += (new_w / 2.0) - centre[0]
    mat[1, 2] += (new_h / 2.0) - centre[1]

    border = 255 if img.ndim == 2 else (255, 255, 255)
    return cv2.warpAffine(
        img, mat, (new_w, new_h),
        flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=border,
    )


def preprocess(raw: bytes) -> PreprocessResult:
    """Run the full preprocessing chain on raw upload bytes.

    Raises:
        ImageDecodeError: propagated from decode_image.
    """
    img = decode_image(raw)
    img, downscaled = _downscale(img)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Non-local-means: preserves stroke edges much better than a Gaussian blur,
    # which matters for the thin horizontal shirorekha in Devanagari script.
    denoised = cv2.fastNlMeansDenoising(gray, None, h=10, templateWindowSize=7, searchWindowSize=21)

    skew = _estimate_skew(denoised)
    deskewed = _rotate(denoised, skew)

    # CLAHE instead of global equalisation: scans are unevenly lit (book spine
    # shadow, flash hotspot) and global EQ blows out the bright half.
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(deskewed)

    binary = cv2.adaptiveThreshold(
        clahe, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, blockSize=31, C=11
    )

    blur_score = float(cv2.Laplacian(clahe, cv2.CV_64F).var())
    illegible = blur_score < BLUR_THRESHOLD

    chosen = binary if OCR_INPUT == "binary" else clahe
    ocr_input = cv2.cvtColor(chosen, cv2.COLOR_GRAY2BGR)

    h, w = clahe.shape[:2]
    logger.info(
        "Preprocessed: %dx%d skew=%.2fdeg blur=%.1f illegible=%s input=%s",
        w, h, skew, blur_score, illegible, OCR_INPUT,
    )

    return PreprocessResult(
        ocr_input=ocr_input,
        clahe_gray=clahe,
        binary=binary,
        width=w,
        height=h,
        skew_angle_deg=round(skew, 2),
        blur_score=round(blur_score, 2),
        is_likely_illegible=illegible,
        downscaled=downscaled,
    )
